"use strict";
const myTittle = document.createElement("h2");
myTittle.textContent = "hola me crearon en codigo";

document.body.appendChild(myTittle);