'use strict'
// Operadores logicos 
/**
 * > mayor 
 * < menor
 * >= <=
 * ==
 * === elemto y tipo
 * !=
 * !==
 * *
 * +
 * -
 * %
 * logicos boleamos 
 * &&  
 */ 

let num1;
let num2;
num1 = 9;
num2 = '9'
//el ternario : abreviacion del if else 

let result;
result = (num1 == num2) ? "son iguales" : "no son iguales";
console.log(result);
