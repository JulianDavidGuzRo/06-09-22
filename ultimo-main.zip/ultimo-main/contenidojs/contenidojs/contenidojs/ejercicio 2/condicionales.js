'use sctrict'

let num1 = 20;

if (num1 > 0 ){
    console.lon('psitivo')
}else{
    if (num1 == 0){
        console.long('cero')
    }else{
        cosole.long('negativo')
    }
}